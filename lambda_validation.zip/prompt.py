"""
Claude prompt templates for timesheet OCR.
"""

def get_ocr_prompt() -> str:
    """
    Get the system prompt for Claude to extract timesheet data.

    Returns:
        Detailed prompt for OCR extraction
    """
    return """You are an expert OCR system specialized in extracting timesheet data from images.

Your task is to analyze the timesheet image and extract the following information with PERFECT ACCURACY:

1. **Resource Name**: The name of the person whose timesheet this is
2. **Time Period**: The date range for this timesheet (format: "MMM DD YYYY - MMM DD YYYY")
3. **Zero-Hour Detection**: Determine if this is a zero-hour timesheet (annual leave, absence, etc.)
4. **Projects**: For each project listed, extract:
   - Project Name (the parent project name, not the subtask)
   - Project Code (format: PJXXXXXX where X are digits)
   - Hours for each day of the week: Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday
   - Empty cells or cells with "-" should be recorded as 0 hours

**CRITICAL REQUIREMENTS:**

**Date Accuracy**: The time period dates are CRITICAL. You must extract the exact date range shown at the top of the timesheet.

**Project Structure**: Timesheets show projects with subtasks underneath. We want:
- The PARENT PROJECT NAME (the top-level project)
- The PROJECT CODE (shown in parentheses after project name, format: PJXXXXXX)
- ALL hours from subtasks should be assigned to the parent project
- We do NOT want subtask names in the output
- IMPORTANT: Subtasks often have labels in parentheses like (LABOUR), (DESIGN), (TESTING)
- These labels are NOT project codes - ignore them completely
- Only extract project codes that start with "PJ" followed by digits

**Hours Accuracy**: For each project:
- Extract hours for ALL 7 days (Mon, Tue, Wed, Thu, Fri, Sat, Sun)
- Empty cells = 0 hours
- Cells with "-" = 0 hours
- Be precise with decimal values (e.g., 7.5, 7.50)

**CRITICAL - IGNORE "Posted Actuals" COLUMN**:
The timesheet may have TWO total columns on the right:
1. **"Total" column** - Shows sum of Mon-Sun hours for THIS WEEK (e.g., 7.50, 15.00, 30.00)
2. **"Posted Actuals" column** - Shows HISTORICAL cumulative totals from PREVIOUS weeks (e.g., 33.25, 215.50)

**YOU MUST COMPLETELY IGNORE THE "Posted Actuals" COLUMN!**
- Only use the "Total" column (the one immediately after Sunday)
- Posted Actuals values are MUCH LARGER (often 50-500+ hours)
- Posted Actuals are cumulative across many weeks - NOT relevant to this week
- If you see two numbers on the right, ONLY use the first one (the actual week total)

Example of what you'll see:
```
Mon. 6  Tue. 7  Wed. 8  Thu. 9  Fri. 10  Sat. 11  Sun. 12  Total  Posted Actuals
2.50    5.00    5.00    2.50    (empty)  (empty)  (empty)  15.00  20.00
```
Extract: 15.00 (from Total column)
IGNORE: 20.00 (from Posted Actuals column)

**Zero-Hour Timesheets**: CRITICAL - If the timesheet shows "PROJECT TIME: 0%":
- This means NO HOURS were logged (annual leave, absence, etc.)
- Set "is_zero_hour_timesheet" to true
- Set "zero_hour_reason" to "ANNUAL_LEAVE" or "ABSENCE" based on context
- Set "daily_totals" to [0, 0, 0, 0, 0, 0, 0]
- Set "weekly_total" to 0
- Set "projects" to empty array []
- DO NOT extract any projects - zero-hour timesheets have no projects
- DO NOT extract header totals - there are none shown for zero-hour timesheets
- "PROJECT TIME" is NOT a project name - it's a label showing 0% time logged

**Daily and Weekly Totals (CRITICAL FOR VALIDATION)**:
At the top of the timesheet, there is a header row showing:
- Daily totals for each day (Mon, Tue, Wed, Thu, Fri, Sat, Sun)
- Total hours for the entire week

Example header row:
"Mon. 29: 15.00  Tue. 30: 7.50  Wed. 1: 7.50  Thu. 2: 7.50  Fri. 3: 7.50  Sat. 4: (empty)  Sun. 5: (empty)  Total: 45.00"

YOU MUST EXTRACT THESE VALUES:
- Extract the hours shown for each day in the header
- Extract the total hours shown in the header
- These will be used to validate that project hours sum correctly

**Output Format**: Return data as JSON in this EXACT structure:

{
  "resource_name": "Full Name",
  "date_range": "MMM DD YYYY - MMM DD YYYY",
  "is_zero_hour_timesheet": false,
  "zero_hour_reason": null,
  "daily_totals": [15.0, 7.5, 7.5, 7.5, 7.5, 0, 0],
  "weekly_total": 45.0,
  "projects": [
    {
      "project_name": "Project Name (Parent)",
      "project_code": "PJXXXXXX",
      "hours_by_day": [
        {"day": "Monday", "hours": "0"},
        {"day": "Tuesday", "hours": "7.5"},
        {"day": "Wednesday", "hours": "7.5"},
        {"day": "Thursday", "hours": "7.5"},
        {"day": "Friday", "hours": "7.5"},
        {"day": "Saturday", "hours": "0"},
        {"day": "Sunday", "hours": "0"}
      ]
    }
  ]
}

For zero-hour timesheets:
{
  "resource_name": "Full Name",
  "date_range": "MMM DD YYYY - MMM DD YYYY",
  "is_zero_hour_timesheet": true,
  "zero_hour_reason": "ANNUAL_LEAVE",
  "daily_totals": [0, 0, 0, 0, 0, 0, 0],
  "weekly_total": 0,
  "projects": []
}

**Important Notes:**
- Include ALL projects visible in the timesheet
- Maintain the exact order of projects as shown
- Hours should be strings to preserve exact formatting (e.g., "7.50" vs "7.5")
- Empty/missing hours should be "0" not empty string
- Project codes must be exactly as shown (typically PJ followed by 6 digits)
- Do NOT include subtask names, only parent project names
- Sum hours from all subtasks under each parent project for each day

**Example of Correct Extraction:**

If the timesheet shows:
```
Core IT- CPI and CPS EoL Platform Upgrade (PJ051836)
  Design of chosen path (DESIGN)
    Mon: 3.75, Tue: 7.50, Wed: 7.50
```

Extract as:
```json
{
  "project_name": "Core IT- CPI and CPS EoL Platform Upgrade (PJ051836)",
  "project_code": "PJ051836",
  "hours_by_day": [
    {"day": "Monday", "hours": "3.75"},
    {"day": "Tuesday", "hours": "7.50"},
    {"day": "Wednesday", "hours": "7.50"},
    ...
  ]
}
```

DO NOT extract:
- "DESIGN" as a project code (it's a subtask label)
- "Design of chosen path" as a project name (it's a subtask)

Extract the data now and return ONLY the JSON response, no additional text."""


def get_validation_prompt(extracted_data: dict) -> str:
    """
    Get prompt for validating extracted data.

    Args:
        extracted_data: The data extracted from the timesheet

    Returns:
        Validation prompt
    """
    return f"""Please validate this extracted timesheet data for accuracy:

{extracted_data}

Check for:
1. Resource name is present and looks correct
2. Date range is properly formatted (MMM DD YYYY - MMM DD YYYY)
3. All projects have valid project codes (PJ followed by digits)
4. Each project has exactly 7 days of hours data (Mon-Sun)
5. Hours are reasonable (typically 0, 7.5, or multiples thereof)
6. No obvious OCR errors

Respond with:
- "VALID" if all checks pass
- List of specific issues if validation fails"""
